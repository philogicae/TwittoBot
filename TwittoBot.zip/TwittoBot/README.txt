Projet TALN 2018
Aix-Marseille Université

Réalisé par Arnaud SOULIER et Mathieu REMY

(Certains lourds fichiers ont été supprimés, pour réduire la taille du projet)


IMPORTANT : 

Pour les modules et corpus manquants dans NLTK,
il faut ouvrir Python dans un terminal, puis faire :

import nltk
nltk.download()

puis sélectionner les modules manquants pour les télécharger.